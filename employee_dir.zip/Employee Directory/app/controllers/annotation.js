var args = arguments[0] || {};

$.avatar.image = args.image;
